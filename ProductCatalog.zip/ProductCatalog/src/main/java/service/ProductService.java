import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ProductService {

    private final ProductRepository productRepository;

    // Constructor injection is clean, testable, and preferred over @Autowired fields
    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }
	
    //  Retrieve all available products.

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    //Find a product by its ID or throw an exception if it doesn't exist.
   
    public Product getProductById(Long id) {
        return productRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Product not found with ID: " + id));
    }

    // Create a new product after validating basic business rules.
  
    public Product createProduct(Product product) {
        if (product.price() < 0) {
            throw new IllegalArgumentException("Product price cannot be negative.");
        }
        
        if (product.name() == null || product.name.isBlank()) {
            throw new IllegalArgumentException("Product name cannot be blank.");
        }

        return productRepository.save(product);
    }
}